sudo systemctl restart httpd
